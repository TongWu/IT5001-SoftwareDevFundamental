##############
# Question 1 #
##############

def floyd_row(n):
    pass


def floyd_sum(n):
    pass


# Tests
def test_q1a():
    print(floyd_row(1))
    print(floyd_row(2))
    print(floyd_row(5))


def test_q1b():
    print(floyd_sum(1))
    print(floyd_sum(2))
    print(floyd_sum(5))


# Uncomment to test
##test_q1a()
##test_q1b()



##############
# Question 2 #
##############

import csv
def read_csv(csvfilename):
    """
    Reads a csv file and returns a list of list
    containing rows in the csv file and its entries.
    """
    rows = []

    with open(csvfilename, encoding='utf-8') as csvfile:
        file_reader = csv.reader(csvfile)
        for row in file_reader:
            rows.append(row)
    return rows


### Your answer here.
# Q2A
def regional_sales(filename, platform, year):
    pass


# Q2B      
def trending_genre(filename, platform):
    pass



# Tests
def test_q2a():
    print(regional_sales("vgsales.csv", "X360", 2016))
    print(regional_sales("vgsales.csv", "3DS", 2012))


def test_q2b():
    print(trending_genre("vgsales.csv", "PS3") == \
        {2013: 'Misc', 2014: 'Misc', 2015: 'Simulation', 2016: 'Role-Playing'})
    print(trending_genre("vgsales.csv", "PC") == \
        {2013: 'Misc', 2014: 'Simulation', 2015: 'Strategy', 2016: 'Adventure'})


##test_q2a()
##test_q2b()

    

##############
# Question 3 #
##############

class Stone:
    pass


class Artefact:
    pass




# Test cases

def test_q3():
    power_stone   = Stone("Power Stone", "Attack", "Defense")
    mind_stone    = Stone("Mind Stone", "Brainwash")
    time_stone    = Stone("Time Stone")
    reality_stone = Stone("Reality Stone", "Illusion")

    vision          = Artefact("Vision", mind_stone)
    gauntlet        = Artefact("Gauntlet", power_stone)
    eye_of_agamotto = Artefact("Eye of Agamoto")

    mind_stone_remade = Stone("Mind Stone", "Brainwash", "Illusion")

    _=power_stone.imbue("Attack"); print(_ == 'Power Stone already imbued with the power Attack', '\tpower_stone.imbue("Attack"):\t', _)
    _=power_stone.imbue("Strength"); print(_ == 'Power Stone is now imbued with the power Strength', '\tpower_stone.imbue("Strength"):\t', _)
    _=power_stone.list_powers(); print(tuple(sorted(_)) == ('Attack', 'Defense', 'Strength'), '\tpower_stone.list_powers():\t', _)
    _=time_stone.imbue("Repeat"); print(_ == 'Time Stone is now imbued with the power Repeat', '\ttime_stone.imbue("Repeat"):\t', _)
    _=time_stone.imbue("Undo"); print(_ == 'Time Stone is now imbued with the power Undo', '\ttime_stone.imbue("Undo"):\t', _)
    _=vision.add_stone(mind_stone); print(_ == 'Vision already has Mind Stone', '\tvision.add_stone(mind_stone):\t', _)
    _=vision.remove_stone(power_stone); print(_ == 'Vision does not contain Power Stone', '\tvision.remove_stone(power_stone):\t', _)
    _=vision.remove_stone(mind_stone); print(_ == 'Mind Stone is removed from Vision', '\tvision.remove_stone(mind_stone):\t', _)
    _=vision.add_stone(mind_stone); print(_ == 'Mind Stone is added to Vision', '\tvision.add_stone(mind_stone):\t', _)
    _=vision.invoke(); print(tuple(sorted(_)) == ('Brainwash',), '\tvision.invoke():\t', _)
    _=vision.add_stone(power_stone); print(_ == 'Power Stone is already part of Gauntlet', '\tvision.add_stone(power_stone):\t', _)
    _=mind_stone.disarm("AI"); print(_ == 'Mind Stone is not imbued with the power AI', '\tmind_stone.disarm("AI"):\t', _)
    _=mind_stone.destroy(); print(_ == 'Mind Stone is now destroyed', '\tmind_stone.destroy():\t', _)
    _=mind_stone.disarm("Brainwash"); print(_ == 'Mind Stone already destroyed', '\tmind_stone.disarm("Brainwash"):\t', _)
    _=vision.remove_stone(mind_stone); print(_ == 'Vision does not contain Mind Stone', '\tvision.remove_stone(mind_stone):\t', _)
    _=eye_of_agamotto.add_stone(time_stone); print(_ == 'Time Stone is added to Eye of Agamoto', '\teye_of_agamotto.add_stone(time_stone):\t', _)
    _=vision.combine(eye_of_agamotto); print(_ == 'Vision combines with Eye of Agamoto', '\tvision.combine(eye_of_agamotto):\t', _)
    _=eye_of_agamotto.combine(vision); print(_ == 'Eye of Agamoto is already combined with Vision', '\teye_of_agamotto.combine(vision):\t', _)
    _=gauntlet.add_stone(mind_stone); print(_ == 'Mind Stone is already destroyed', '\tgauntlet.add_stone(mind_stone):\t', _)
    _=gauntlet.add_stone(mind_stone_remade); print(_ == 'Mind Stone is added to Gauntlet', '\tgauntlet.add_stone(mind_stone_remade):\t', _)
    _=gauntlet.invoke(); print(tuple(sorted(_)) == ('Attack', 'Brainwash', 'Defense', 'Illusion', 'Strength'), '\tgauntlet.invoke():\t', _)
    _=gauntlet.add_stone(reality_stone); print(_ == 'Reality Stone is added to Gauntlet', '\tgauntlet.add_stone(reality_stone):\t', _)
    _=gauntlet.invoke(); print(tuple(sorted(_)) == ('Attack', 'Brainwash', 'Defense', 'Illusion', 'Strength'), '\tgauntlet.invoke():\t', _)
    _=gauntlet.combine(eye_of_agamotto); print(_ == 'Gauntlet combines with Eye of Agamoto', '\tgauntlet.combine(eye_of_agamotto):\t', _)
    _=gauntlet.combine(vision); print(_ == 'Gauntlet is already combined with Vision', '\tgauntlet.combine(vision):\t', _)
    _=gauntlet.invoke(); print(tuple(sorted(_)) == ('Attack', 'Brainwash', 'Defense', 'Illusion', 'Repeat', 'Strength', 'Undo'), '\tgauntlet.invoke():\t', _)

# Uncomment to test question 3
##test_q3()    
