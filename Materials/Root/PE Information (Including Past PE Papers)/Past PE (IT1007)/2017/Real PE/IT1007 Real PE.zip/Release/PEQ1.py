
def compute_e_within_error(err):
    return 0

# For your own testing and debugging
e = compute_e_within_error(0.99)
print('e = '+str(e))

e = compute_e_within_error(0.01)
print('e = '+str(e))

e = compute_e_within_error(0.0000000000000000001)
print('e = '+str(e))


        
