def q(x):
    return 5 * x ** 4

def int_q(x):
    return x**5

def numeric_integral(l,r,delta_x):
    return 0


#Uncomment the following for your own testing

#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology

'''
print(numeric_integral(-1,0,0.0001))
print(numeric_integral(-1,0,0.0000001))
# This should not take more than 1 min.

print('True integral of q from -1 to 0 = ' +str(int_q(0)-int_q(-1)))


print(numeric_integral(0,2,0.0001))
print(numeric_integral(0,2,0.0000001))
# This should not take more than 1 min.

print('True integral of q from 0 to 2 = ' +str(int_q(2)-int_q(0)))
'''


