from scipy import misc,ndimage
import matplotlib.pyplot as plt
import numpy as np


def image_composition(filename1, filename2):
    return

#Uncomment the following for your own testing
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology


#image_composition('avengers green.jpg','background.jpg')


#image_composition('avengers green triangle.jpg','background.jpg')


