from math import cos,sin

def f(x):
    return x**3 + 2*x + 1

def int_f(x):
    return (x**4)/4 + x * x + x

def q(x):
    return 5 * x ** 4

def int_q(x):
    return x**5

def numeric_integral_2(l,r,delta_x,f):
    return 0

#Uncomment the following for your own testing

#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology

'''
print(numeric_integral_2(0,2,0.0000001,sin))

print(cos(0)-cos(2)) #True integral


print(numeric_integral_2(0,2,0.0000001,f))

print(int_f(2)-int_f(0)) #True integral

print(numeric_integral_2(0,2,0.0000001,q))

print(int_q(2)-int_q(0)) #True integral

'''
