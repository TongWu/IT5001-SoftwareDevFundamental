from math import sqrt

def is_squared_sum_num(n):
    return True

#Uncomment the following for your own testing

#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology
#you should not submit this part to the coursemology

#is_squared_sum_num(18)
#is_squared_sum_num(19)
#is_squared_sum_num(200)
#is_squared_sum_num(20000)
#is_squared_sum_num(1356446145698)
#is_squared_sum_num(1356446145699)
#is_squared_sum_num(390982172680606)
#is_squared_sum_num(3909821726806060898)

